Thanks for downloading and enjoying this pack.

Link:
https://www.curseforge.com/minecraft/texture-packs/weeb-player-mob-models/files



There are things that you're allowed and not allowed to do.

You have permissions to:
= Study or reverse engineer of this pack.
= Use of some entity model files (Must Credit Me).
= Modify it however you want, but don't repost it.


You have NO permission to:
= Repost or steal this pack.
= Use of this pack for your pack (Like RLCraft
  having a bunch of modpacks mixed together as one).
= Repost of every skins from my pack, cuz some of
  these ain't mine. I have textures that I made by myself,
  but still no. I'm gonna just post the skins myself someday.



If you see someone doing the things that are not
allowed, report it to me or the moderators.

-Human Villagers is authorized by the author-
Link: https://www.curseforge.com/minecraft/texture-packs/human-player-villagers-vanilla-style